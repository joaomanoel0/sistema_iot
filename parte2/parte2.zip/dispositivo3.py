import socket
import threading
import protobuf_messages_pb2  # Importe suas definições de mensagens Protocol Buffers aqui
import struct
import sys
import time
import random
import numpy as np

def get_public_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.connect(("8.8.8.8", 80))  # Use um servidor DNS público como o Google DNS
    public_ip = sock.getsockname()[0]
    sock.close()
    return public_ip



def main():
    multicast_group = "224.0.0.1"
    multicast_port = 54321
    DEVICE_HOST = get_public_ip()
    DEVICE_PORT = 8090

    # Crie um socket UDP para escutar o grupo multicast
    multicast_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    multicast_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    multicast_socket.bind(("", multicast_port))

    group = socket.inet_aton(multicast_group)
    mreq = struct.pack("4sL", group, socket.INADDR_ANY)
    multicast_socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    print(f"Dispositivo ouvindo em {multicast_group}:{multicast_port}")

    while True:
        data, addr = multicast_socket.recvfrom(1024)
        discovery_message = protobuf_messages_pb2.Discovery()
        discovery_message.ParseFromString(data)

        # Adicione um print para verificar a mensagem de descoberta
        print(f"Recebido: {discovery_message.message}")

        if discovery_message.message == "Descoberta de dispositivos: Quem está aí?":
            # Agora, crie um novo socket UDP de servidor para aguardar a conexão do Gateway
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

            # Crie uma mensagem de identificação usando Protocol Buffers
            identification_message = protobuf_messages_pb2.Identification()
            identification_message.device_type = "Sensor de Temperatura"
            identification_message.device_ip = DEVICE_HOST
            identification_message.device_port = DEVICE_PORT
            identification_message.protocol = "UDP"  # Adicione o protocolo (UDP ou TCP) conforme necessário

            # Adicione um print para verificar a mensagem de identificação
            print(f"Enviado: {identification_message}")

            # Envie a mensagem de identificação para o gateway
            multicast_socket.sendto(identification_message.SerializeToString(), addr)

            print(f"Dispositivo iniciado no endereço {DEVICE_HOST}:{DEVICE_PORT}")

            while True:
                # Simulação de leitura de temperatura (envio contínuo)
                temperature_data = read_temperature_data()  # Função para simular a leitura de temperatura
                print(temperature_data)
                server_socket.sendto(temperature_data.SerializeToString(), (DEVICE_HOST, DEVICE_PORT))

                time.sleep(4)  # Aguarda 1 segundo antes de enviar a próxima leitura de temperatura

def read_temperature_data():
    temperature_message = protobuf_messages_pb2.DeviceToGatewayMessage()
    mean_temperature = 25.0  # Média de temperatura
    std_deviation = 2.0      # Desvio padrão da temperatura

    temperature_value = round(np.random.normal(mean_temperature, std_deviation), 1)
    temperature_message.response = f"{temperature_value}°C"
    return temperature_message

if __name__ == "__main__":
    main()


